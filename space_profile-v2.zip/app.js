// Maps of Making — hi-fi prototype
// Fullscreen MapLibre + slide-in drawers. Minimal cognitive load.
// Data: data/moms_seed.json (synthetic).

(function () {
  'use strict';

  // ───────────────────────────── state
  const state = {
    spaces: [],
    filters: {
      networks: new Set(),     // empty = all
      countries: new Set(),
      statuses: new Set(),
      specialties: new Set(),
    },
    search: '',
    selectedId: null,
    openDrawer: null,          // 'filters' | 'search' | 'preset' | 'addurl' | 'detail' | 'bot' | 'tweaks' | null
    tweaks: {
      mapStyle: 'paper',
      accent: 'red',
      density: 'roomy',
      pulse: 'on',
    },
    markers: new Map(),        // id -> maplibre.Marker
  };

  // ───────────────────────────── dom helpers
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  function el(tag, attrs = {}, children = []) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') n.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(n.style, v);
      else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
      else if (v === true) n.setAttribute(k, '');
      else if (v === false || v == null) {}
      else n.setAttribute(k, v);
    }
    for (const c of [].concat(children)) {
      if (c == null) continue;
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return n;
  }

  // ───────────────────────────── data
  async function loadData() {
    const res = await fetch('data/moms_seed.json');
    if (!res.ok) throw new Error('seed load failed');
    const json = await res.json();
    state.spaces = json.spaces || [];
  }

  // ───────────────────────────── map
  let map;
  function initMap() {
    // OSM raster tiles via MapLibre — no API key needed.
    // Attribution required; we render it subtly.
    map = new maplibregl.Map({
      container: 'map',
      style: {
        version: 8,
        sources: {
          osm: {
            type: 'raster',
            // Carto's OSM-based tiles ship CORS headers and tend to work in
            // sandboxed iframes; fall through to tile.openstreetmap.org.
            tiles: [
              'https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png',
              'https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png',
              'https://c.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png'
            ],
            tileSize: 256,
            attribution: '© OpenStreetMap · © CARTO',
            maxzoom: 19,
          }
        },
        layers: [{ id: 'osm', type: 'raster', source: 'osm' }],
      },
      center: [4.8, 49.5],   // rough midpoint FR/DE
      zoom: 4.3,
      hash: false,
      attributionControl: { compact: true },
    });
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'bottom-right');

    const dismissLoader = () => {
      const ld = $('#loader');
      if (!ld) return;
      ld.style.transition = 'opacity 300ms';
      ld.style.opacity = '0';
      setTimeout(() => ld.remove(), 320);
    };
    map.on('load', () => { renderMarkers(); dismissLoader(); });
    // Fallback: if tiles are blocked or load is slow, dismiss anyway.
    setTimeout(() => { try { renderMarkers(); } catch {} dismissLoader(); }, 1500);

    // Close drawers when clicking the map
    map.on('click', (e) => {
      // Only close if we didn't click on a marker element
      const target = e.originalEvent.target;
      if (target && target.closest && target.closest('.map-marker')) return;
      // leave drawers where user put them — this is map-first; only close detail
      if (state.openDrawer === 'detail') setDrawer(null);
    });
  }

  function renderMarkers() {
    // Remove old
    state.markers.forEach((m) => m.remove());
    state.markers.clear();
    const visible = filteredSpaces();
    for (const s of visible) {
      const kind = markerKind(s);
      const node = document.createElement('button');
      node.className = `map-marker ${kind}`;
      node.setAttribute('aria-label', `${s.name}, ${s.city}, ${s.country}, status ${kind}`);
      node.type = 'button';
      if (state.tweaks.density === 'compact') {
        node.style.width = '14px';
        node.style.height = '14px';
      }
      if (state.tweaks.pulse === 'off') {
        node.style.setProperty('--no-pulse', '1');
        if (kind === 'open') node.classList.add('no-pulse');
      }
      node.addEventListener('click', (e) => {
        e.stopPropagation();
        selectSpace(s.id, { fly: false });
      });
      // Let MapLibre handle centering via its default anchor class.
      const marker = new maplibregl.Marker({ element: node })
        .setLngLat([s.coordinates.lon, s.coordinates.lat])
        .addTo(map);
      state.markers.set(s.id, marker);
    }
    // Reselect highlight if needed
    if (state.selectedId) highlightSelected();
    updateCounts();
  }

  function markerKind(s) {
    if (s.status === 'broken') return 'broken';
    if (s.status === 'stale') return 'stale';
    if (s.open_now) return 'open';
    if (s.status === 'confirmed') return 'confirmed';
    return 'seeded';
  }

  function highlightSelected() {
    state.markers.forEach((m, id) => {
      const nd = m.getElement();
      if (id === state.selectedId) nd.classList.add('selected');
      else nd.classList.remove('selected');
    });
  }

  function selectSpace(id, opts = {}) {
    state.selectedId = id;
    highlightSelected();
    renderDetail();
    // If add-url is open, don't hijack; else open detail drawer
    if (state.openDrawer !== 'addurl') setDrawer('detail');
    if (opts.fly) {
      const s = state.spaces.find((x) => x.id === id);
      if (s) map.flyTo({ center: [s.coordinates.lon, s.coordinates.lat], zoom: Math.max(map.getZoom(), 8), speed: 1.2 });
    }
  }

  // ───────────────────────────── filtering
  function filteredSpaces() {
    const f = state.filters;
    const q = state.search.trim().toLowerCase();
    return state.spaces.filter((s) => {
      if (f.networks.size && !s.network_memberships.some((n) => f.networks.has(n))) return false;
      if (f.countries.size && !f.countries.has(s.country)) return false;
      if (f.statuses.size) {
        const tag = markerKind(s);
        if (!f.statuses.has(tag)) return false;
      }
      if (f.specialties.size && !s.specialties.some((sp) => f.specialties.has(sp))) return false;
      if (q) {
        const hay = (s.name + ' ' + s.city + ' ' + s.country + ' ' + s.specialties.join(' ') + ' ' + s.network_memberships.join(' ')).toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }

  function updateCounts() {
    const visible = filteredSpaces();
    const total = state.spaces.length;
    $('#results-count').textContent = String(visible.length);
    $('#drawer-count').textContent = `${visible.length} / ${total}`;
    renderResultsList(visible);
    renderPresetPreview();
    const filterN = state.filters.networks.size + state.filters.countries.size + state.filters.statuses.size + state.filters.specialties.size + (state.search ? 1 : 0);
    $('#filters-summary').textContent = filterN ? `${filterN} filter${filterN > 1 ? 's' : ''} on` : '';
  }

  // ───────────────────────────── filter chips
  function buildFilterChips() {
    // Networks
    const networks = unique(state.spaces.flatMap((s) => s.network_memberships));
    const countries = unique(state.spaces.map((s) => s.country));
    const statuses = ['seeded', 'confirmed', 'open', 'stale', 'broken'];
    const specialties = unique(state.spaces.flatMap((s) => s.specialties)).sort();

    renderChips('#chips-network', networks, state.filters.networks);
    renderChips('#chips-country', countries.map((c) => [c, countryLabel(c)]), state.filters.countries);
    renderChips('#chips-status', statuses.map((s) => [s, s]), state.filters.statuses, { swatch: true });
    renderChips('#chips-spec', specialties, state.filters.specialties);
  }

  function renderChips(selector, values, set, opts = {}) {
    const host = $(selector);
    host.innerHTML = '';
    for (const v of values) {
      const [val, label] = Array.isArray(v) ? v : [v, v];
      const count = state.spaces.filter((s) => chipMatches(selector, s, val)).length;
      const btn = el('button', { class: 'chip', 'aria-pressed': set.has(val) ? 'true' : 'false', type: 'button' }, [
        opts.swatch ? el('span', { class: `pin-swatch ${val}` }) : null,
        label.replace(/-/g, ' '),
        el('span', { class: 'count' }, [String(count)])
      ]);
      btn.addEventListener('click', () => {
        if (set.has(val)) set.delete(val); else set.add(val);
        btn.setAttribute('aria-pressed', set.has(val) ? 'true' : 'false');
        renderMarkers();
      });
      host.appendChild(btn);
    }
  }

  function chipMatches(selector, s, val) {
    if (selector === '#chips-network') return s.network_memberships.includes(val);
    if (selector === '#chips-country') return s.country === val;
    if (selector === '#chips-status') return markerKind(s) === val;
    if (selector === '#chips-spec') return s.specialties.includes(val);
    return false;
  }

  function countryLabel(c) { return c === 'FR' ? '🇫🇷 France' : c === 'DE' ? '🇩🇪 Germany' : c; }

  function unique(arr) { return Array.from(new Set(arr)); }

  // ───────────────────────────── results list
  function renderResultsList(visible) {
    const host = $('#results-list');
    host.innerHTML = '';
    if (!visible.length) {
      host.appendChild(el('div', { style: { padding: '24px 14px', color: 'var(--muted)', fontSize: '13px' } }, ['No spaces match these filters.']));
      return;
    }
    for (const s of visible.slice(0, 200)) {
      const kind = markerKind(s);
      const item = el('button', { class: 'result', role: 'option', 'aria-selected': state.selectedId === s.id ? 'true' : 'false', type: 'button' }, [
        el('span', { class: `pin-swatch ${kind}`, style: { marginTop: '2px' } }),
        el('div', { style: { flex: 1, minWidth: 0 } }, [
          el('div', { class: 'name' }, [s.name]),
          el('div', { class: 'meta' }, [`${s.city}, ${s.country} · ${s.network_memberships.join(' · ')}`]),
          el('div', { class: 'tags' }, s.specialties.slice(0, 4).map((sp) => el('span', { class: 'tag' }, [sp]))),
        ]),
        el('span', { class: `status-label ${kind}`, style: { alignSelf: 'flex-start' } }, [kind])
      ]);
      item.addEventListener('click', () => selectSpace(s.id, { fly: true }));
      host.appendChild(item);
    }
  }

  // ───────────────────────────── detail drawer
  function renderDetail() {
    const body = $('#detail-body');
    body.innerHTML = '';
    const s = state.spaces.find((x) => x.id === state.selectedId);
    if (!s) {
      body.appendChild(el('div', { style: { padding: '24px', color: 'var(--muted)' } }, ['Click a pin to see details.']));
      return;
    }
    const kind = markerKind(s);
    // Hero
    body.appendChild(el('div', { class: 'detail-hero' }, [
      el('h3', {}, [s.name]),
      el('div', { class: 'where' }, [`${s.address}`]),
      el('div', { class: 'badges' }, [
        el('span', { class: `status-label ${kind}` }, [kind]),
        ...s.network_memberships.map((n) => el('span', { class: 'status-label', style: { textTransform: 'none', color: 'var(--accent-2)', borderColor: 'var(--accent-2)' } }, [n])),
        s.open_for_hosting ? el('span', { class: 'status-label', style: { textTransform: 'none' } }, ['open for hosting']) : null,
      ])
    ]));
    // Freshness
    body.appendChild(el('div', { class: `freshness ${kind}` }, [
      el('span', { class: 'dot' }),
      el('span', {}, [freshnessText(s)])
    ]));
    // Quick facts
    body.appendChild(el('div', { class: 'detail-section' }, [
      el('div', { class: 'wf-label' }, ['Quick facts']),
      el('dl', { class: 'kv' }, [
        el('dt', {}, ['Hours']), el('dd', {}, [s.opening_hours]),
        el('dt', {}, ['Founded']), el('dd', {}, [String(s.founded)]),
        el('dt', {}, ['Capacity']), el('dd', {}, [`${s.capacity} members`]),
        el('dt', {}, ['Contact']), el('dd', {}, [el('a', { href: `mailto:${s.contact}` }, [s.contact])]),
        el('dt', {}, ['Website']), el('dd', {}, [el('a', { href: s.website, target: '_blank', rel: 'noopener' }, [s.website.replace(/^https?:\/\//, '')])]),
      ])
    ]));
    // Specialties
    body.appendChild(el('div', { class: 'detail-section' }, [
      el('div', { class: 'wf-label' }, ['Specialties']),
      el('div', { class: 'chips' }, s.specialties.map((sp) => el('span', { class: 'chip', 'aria-pressed': 'false', style: { cursor: 'default' } }, [sp])))
    ]));
    // JSON
    body.appendChild(el('div', { class: 'detail-section', style: { padding: 0 } }, [
      el('div', { class: 'wf-label', style: { padding: '12px 16px 0' } }, ['Raw JSON from endpoint']),
      el('pre', { class: 'json' }, [jsonHighlight(jsonForSpace(s))])
    ]));
  }

  function freshnessText(s) {
    if (s.status === 'seeded') return 'Seeded by network — not yet confirmed by the space.';
    if (s.status === 'broken') return `URL broken · last successful fetch: ${timeAgo(s.last_fetched)}.`;
    if (s.status === 'stale') return `Stale · last fetched ${timeAgo(s.last_fetched)} ago.`;
    if (s.open_now) return `Open right now · last fetched ${timeAgo(s.last_fetched)} ago.`;
    return `Confirmed · last fetched ${timeAgo(s.last_fetched)} ago.`;
  }

  function timeAgo(iso) {
    if (!iso) return 'never';
    const t = new Date(iso).getTime();
    const sec = (Date.now() - t) / 1000;
    if (sec < 60) return `${Math.round(sec)}s`;
    if (sec < 3600) return `${Math.round(sec / 60)}m`;
    if (sec < 86400) return `${Math.round(sec / 3600)}h`;
    return `${Math.round(sec / 86400)}d`;
  }

  function jsonForSpace(s) {
    // Serve a clean "as if from endpoint" shape, per the article
    return {
      name: s.name,
      address: s.address,
      website: s.website,
      contact: s.contact,
      status: s.status === 'broken' ? 'broken' : (s.open_now ? 'open' : (s.status === 'confirmed' ? 'open' : 'unknown')),
      opening_hours: s.opening_hours,
      specialties: s.specialties,
      network_memberships: s.network_memberships,
      open_for_hosting: s.open_for_hosting,
      coordinates: s.coordinates,
      endpoint_url: s.endpoint_url,
      last_fetched: s.last_fetched,
    };
  }

  function jsonHighlight(obj) {
    const txt = JSON.stringify(obj, null, 2);
    // minimal syntax highlight
    const frag = document.createDocumentFragment();
    const re = /("(?:\\.|[^"\\])*")(\s*:)?|(\btrue\b|\bfalse\b|\bnull\b)|(-?\d+(?:\.\d+)?)/g;
    let last = 0, m;
    while ((m = re.exec(txt))) {
      if (m.index > last) frag.appendChild(document.createTextNode(txt.slice(last, m.index)));
      if (m[1]) {
        const span = document.createElement('span');
        span.className = m[2] ? 'k' : 's';
        span.textContent = m[1] + (m[2] || '');
        frag.appendChild(span);
      } else if (m[3]) {
        const span = document.createElement('span');
        span.className = 'c'; span.textContent = m[3]; frag.appendChild(span);
      } else if (m[4]) {
        const span = document.createElement('span');
        span.className = 'n'; span.textContent = m[4]; frag.appendChild(span);
      }
      last = re.lastIndex;
    }
    if (last < txt.length) frag.appendChild(document.createTextNode(txt.slice(last)));
    return frag;
  }

  // ───────────────────────────── preset & embed
  function renderPresetPreview() {
    const visible = filteredSpaces();
    $('#pp-count').textContent = String(visible.length);
    const parts = [];
    if (state.filters.networks.size) parts.push(`networks=${[...state.filters.networks].join(',')}`);
    if (state.filters.countries.size) parts.push(`country=${[...state.filters.countries].join(',')}`);
    if (state.filters.statuses.size) parts.push(`status=${[...state.filters.statuses].join(',')}`);
    if (state.filters.specialties.size) parts.push(`specialty=${[...state.filters.specialties].join(',')}`);
    if (state.search) parts.push(`q=${encodeURIComponent(state.search)}`);
    const q = parts.join('&') || 'all';
    $('#pp-filters').textContent = q;

    const bbox = map ? (() => {
      const b = map.getBounds();
      return `${b.getWest().toFixed(2)},${b.getSouth().toFixed(2)},${b.getEast().toFixed(2)},${b.getNorth().toFixed(2)}`;
    })() : '—';

    const name = $('#preset-name').value.trim() || 'untitled-preset';
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const url = `https://mapsofmaking.org/embed?preset=${slug}&${q}&bbox=${bbox}`;
    const iframe = `<iframe src="${url}"\n        width="100%" height="520"\n        style="border:1.5px solid #1a1a1a"\n        title="${name}"\n        loading="lazy"></iframe>`;
    const wc = `<script src="https://mapsofmaking.org/mom-map.js" defer><\/script>\n<mom-map preset="${slug}"\n         filters="${q}"\n         bbox="${bbox}"></mom-map>`;
    $('#code-iframe-text').textContent = iframe;
    $('#code-wc-text').textContent = wc;
  }

  // ───────────────────────────── add URL (simulated)
  function initAddUrl() {
    const sel = $('#url-space');
    for (const s of [...state.spaces].sort((a,b) => a.name.localeCompare(b.name))) {
      sel.appendChild(el('option', { value: s.id }, [`${s.name} — ${s.city}, ${s.country}`]));
    }
    $('#btn-sample').addEventListener('click', () => {
      const sample = state.spaces.find((s) => s.status === 'seeded');
      if (sample) {
        $('#url-input').value = `${sample.website}/maker.json`;
        $('#url-space').value = sample.id;
      }
    });
    $('#btn-fetch-url').addEventListener('click', () => {
      const out = $('#url-result');
      const url = $('#url-input').value.trim();
      const spaceId = $('#url-space').value;
      if (!url) { out.innerHTML = '<span style="color: var(--accent);">✗ enter a URL first.</span>'; return; }
      out.innerHTML = '<span style="color: var(--muted);">→ resolving DNS… fetching… parsing JSON… validating schema…</span>';
      setTimeout(() => {
        const ok = /^https?:\/\/.+\..+/.test(url);
        if (!ok) {
          out.innerHTML = '<span style="color: var(--accent);">✗ invalid URL shape.</span>';
          return;
        }
        if (spaceId) {
          const s = state.spaces.find((x) => x.id === spaceId);
          if (s) {
            s.status = 'confirmed';
            s.endpoint_url = url;
            s.last_fetched = new Date().toISOString();
            renderMarkers();
            selectSpace(spaceId, { fly: true });
            out.innerHTML = `<span style="color: var(--green);">✓ flipped <b>${s.name}</b> from ⚪ seeded to 🔵 confirmed. Pin updated.</span>`;
            return;
          }
        }
        out.innerHTML = `<span style="color: var(--green);">✓ URL validated (simulated). In production this would enqueue the endpoint for Oxigraph ingestion.</span>`;
      }, 900);
    });
  }

  // ───────────────────────────── drawers / UI wiring
  function setDrawer(name) {
    // Detail & addurl share the right slot — close the other first
    const prev = state.openDrawer;
    if (prev && prev !== name) closeDrawer(prev);
    if (!name) { state.openDrawer = null; return; }
    state.openDrawer = name;
    const id = ({
      filters: 'drawer-filters', search: 'drawer-search', preset: 'drawer-preset',
      addurl: 'drawer-addurl', detail: 'drawer-detail', bot: 'bot-drawer', tweaks: 'tweaks'
    })[name];
    const node = document.getElementById(id);
    if (!node) return;
    node.classList.add('open');
    node.setAttribute('aria-hidden', 'false');
    // Sync top-bar pressed state
    syncTopbar();
    // Focus handling
    const focusable = node.querySelector('input, button, [tabindex]');
    if (focusable && name !== 'detail') focusable.focus({ preventScroll: true });
    // Update preset code if opening preset
    if (name === 'preset') renderPresetPreview();
  }
  function closeDrawer(name) {
    const id = ({
      filters: 'drawer-filters', search: 'drawer-search', preset: 'drawer-preset',
      addurl: 'drawer-addurl', detail: 'drawer-detail', bot: 'bot-drawer', tweaks: 'tweaks'
    })[name];
    const node = document.getElementById(id);
    if (!node) return;
    node.classList.remove('open');
    node.setAttribute('aria-hidden', 'true');
    if (state.openDrawer === name) state.openDrawer = null;
    syncTopbar();
  }
  function toggleDrawer(name) {
    if (state.openDrawer === name) closeDrawer(name);
    else setDrawer(name);
  }
  function syncTopbar() {
    $('#btn-filters').setAttribute('aria-pressed', state.openDrawer === 'filters' ? 'true' : 'false');
    $('#btn-search').setAttribute('aria-pressed', state.openDrawer === 'search' ? 'true' : 'false');
    $('#btn-preset').setAttribute('aria-pressed', state.openDrawer === 'preset' ? 'true' : 'false');
    $('#btn-addurl').setAttribute('aria-pressed', state.openDrawer === 'addurl' ? 'true' : 'false');
    $('#btn-tweaks').setAttribute('aria-pressed', state.openDrawer === 'tweaks' ? 'true' : 'false');
    $('#btn-bot').setAttribute('aria-expanded', state.openDrawer === 'bot' ? 'true' : 'false');
    // When bot drawer is open, hide the FAB
    $('#btn-bot').style.display = state.openDrawer === 'bot' ? 'none' : 'flex';
  }

  function wireUI() {
    $('#btn-filters').addEventListener('click', () => toggleDrawer('filters'));
    $('#btn-search').addEventListener('click', () => toggleDrawer('search'));
    $('#btn-preset').addEventListener('click', () => toggleDrawer('preset'));
    $('#btn-addurl').addEventListener('click', () => toggleDrawer('addurl'));
    $('#btn-tweaks').addEventListener('click', () => toggleDrawer('tweaks'));
    $('#btn-bot').addEventListener('click', () => toggleDrawer('bot'));
    $$('[data-close]').forEach((b) => b.addEventListener('click', () => closeDrawer(b.dataset.close)));

    // ESC closes topmost drawer
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (state.openDrawer) { closeDrawer(state.openDrawer); return; }
      }
      if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
        e.preventDefault();
        setDrawer('search');
      }
    });

    // Search
    const si = $('#search-input');
    si.addEventListener('input', () => {
      state.search = si.value;
      renderMarkers();
    });

    // Reset filters
    $('#btn-reset-filters').addEventListener('click', () => {
      state.filters.networks.clear();
      state.filters.countries.clear();
      state.filters.statuses.clear();
      state.filters.specialties.clear();
      state.search = '';
      $('#search-input').value = '';
      buildFilterChips();
      renderMarkers();
    });

    // Preset name → re-render code
    $('#preset-name').addEventListener('input', renderPresetPreview);
    // Copy buttons
    $$('[data-copy]').forEach((b) => b.addEventListener('click', async () => {
      const id = b.dataset.copy;
      const txt = $('#' + id + '-text').textContent;
      try {
        await navigator.clipboard.writeText(txt);
        const prev = b.textContent; b.textContent = 'copied!';
        setTimeout(() => b.textContent = prev, 1200);
      } catch { b.textContent = 'select & copy'; }
    }));

    // Tweaks
    $$('.tweaks .opts').forEach((group) => {
      const key = group.dataset.tweak;
      group.querySelectorAll('button').forEach((b) => {
        b.addEventListener('click', () => {
          group.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', 'false'));
          b.setAttribute('aria-pressed', 'true');
          state.tweaks[key] = b.dataset.val;
          applyTweaks();
        });
      });
    });

    // Keep preset preview bbox fresh as map moves
    if (map) {
      map.on('moveend', () => { if (state.openDrawer === 'preset') renderPresetPreview(); });
    }
  }

  function applyTweaks() {
    const mapEl = $('#map');
    mapEl.classList.remove('map-paper', 'map-dim', 'map-dark');
    if (state.tweaks.mapStyle !== 'raw') mapEl.classList.add('map-' + state.tweaks.mapStyle);
    // Accent color
    const accents = {
      red:      ['oklch(62% 0.18 25)',  'oklch(55% 0.17 250)'],
      cobalt:   ['oklch(55% 0.17 250)', 'oklch(62% 0.18 25)'],
      forest:   ['oklch(55% 0.14 150)', 'oklch(62% 0.14 80)'],
      marigold: ['oklch(70% 0.16 80)',  'oklch(55% 0.17 250)'],
    };
    const [a1, a2] = accents[state.tweaks.accent] || accents.red;
    document.documentElement.style.setProperty('--accent', a1);
    document.documentElement.style.setProperty('--accent-2', a2);
    renderMarkers();
  }

  // ───────────────────────────── boot
  (async function boot() {
    try {
      await loadData();
      // wait for maplibre
      if (typeof maplibregl === 'undefined') {
        await new Promise((r) => {
          const iv = setInterval(() => { if (typeof maplibregl !== 'undefined') { clearInterval(iv); r(); } }, 40);
        });
      }
      initMap();
      buildFilterChips();
      initAddUrl();
      wireUI();
      updateCounts();
      // Initial tweaks apply
      applyTweaks();
    } catch (e) {
      console.error(e);
      $('#loader').innerHTML = `<div class="hand" style="color: var(--accent)">Couldn't load seed data.</div><div class="mono">${e.message}</div>`;
    }
  })();
})();

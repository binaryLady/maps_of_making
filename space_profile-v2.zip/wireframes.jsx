// Maps of Making — wireframes canvas (5 directions)
// Lo-fi, sketchy, black + riso-red. Real illustrative map placeholders (not tiles yet).

// ─────────────────────────────────────────────────────────
// SketchMap — a fake Europe-ish map shape w/ riso pins
// ─────────────────────────────────────────────────────────
function SketchMap({ style = {}, pins = [], showGrid = true, caption }) {
  // rough continental blobs — pure illustration, not geo-accurate
  return (
    <div className="sketch-map" style={{ width: '100%', height: '100%', position: 'relative', ...style }}>
      <svg viewBox="0 0 400 300" preserveAspectRatio="none">
        {/* land blob */}
        <path d="M40,180 C30,120 80,60 150,55 C220,50 280,70 330,100 C360,120 370,170 340,210 C310,250 250,260 180,250 C120,243 60,230 40,180 Z"
              fill="#ece4d0" stroke="#2a2a2a" strokeWidth="1.6" strokeLinejoin="round" />
        {/* little island */}
        <path d="M70,70 C80,55 110,55 115,75 C120,90 95,95 75,90 Z"
              fill="#ece4d0" stroke="#2a2a2a" strokeWidth="1.4" />
        {/* water hatching */}
        {showGrid && [...Array(14)].map((_, i) => (
          <line key={i} x1={-20 + i*40} y1={-20} x2={-60 + i*40} y2={320}
                stroke="#c9c0ac" strokeWidth="0.6" />
        ))}
        {/* rough river squiggle */}
        <path d="M150,80 C160,120 180,140 200,180 C215,215 235,230 260,235"
              fill="none" stroke="#8aa6cc" strokeWidth="1.4" strokeDasharray="3 2" />
        {/* faint roads */}
        <path d="M60,200 C120,170 180,190 240,170 C300,150 340,160 360,180"
              fill="none" stroke="#b8b0a0" strokeWidth="0.8" />
      </svg>
      {pins.map((p, i) => (
        <span key={i} className={`map-pin pin pin-${p.kind}`}
              style={{ left: `${p.x}%`, top: `${p.y}%` }} title={p.label} />
      ))}
      {caption && (
        <div style={{
          position: 'absolute', bottom: 6, right: 8,
          fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: '#888'
        }}>{caption}</div>
      )}
    </div>
  );
}

const SAMPLE_PINS = [
  // France-ish (left-ish cluster)
  { x: 28, y: 52, kind: 'confirmed', label: 'Paris' },
  { x: 26, y: 68, kind: 'seeded', label: 'Lyon' },
  { x: 22, y: 78, kind: 'seeded', label: 'Marseille' },
  { x: 20, y: 72, kind: 'stale', label: 'Toulouse' },
  { x: 18, y: 58, kind: 'seeded', label: 'Nantes' },
  { x: 30, y: 44, kind: 'confirmed', label: 'Lille' },
  { x: 34, y: 58, kind: 'open', label: 'Strasbourg' },
  // Germany-ish (right cluster)
  { x: 52, y: 44, kind: 'confirmed', label: 'Berlin' },
  { x: 44, y: 42, kind: 'seeded', label: 'Hamburg' },
  { x: 50, y: 62, kind: 'open', label: 'München' },
  { x: 46, y: 52, kind: 'seeded', label: 'Köln' },
  { x: 54, y: 52, kind: 'stale', label: 'Leipzig' },
  { x: 58, y: 50, kind: 'seeded', label: 'Dresden' },
  { x: 48, y: 56, kind: 'broken', label: 'Frankfurt' },
  { x: 56, y: 60, kind: 'confirmed', label: 'Nürnberg' },
];

// little "sketchy squiggle" underline
function Squiggle({ color = '#e23a2a', width = 80 }) {
  return (
    <svg className="squiggle" style={{ width }} viewBox="0 0 100 6" preserveAspectRatio="none">
      <path d="M0,3 C10,0 20,6 30,3 C40,0 50,6 60,3 C70,0 80,6 90,3 L100,3"
            fill="none" stroke={color} strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

// annotation with arrow
function Annotation({ style, children, arrow = 'down-left' }) {
  const arrows = {
    'down-left': <svg width="60" height="40" viewBox="0 0 60 40"><path d="M5,5 C20,10 30,20 50,35" fill="none" stroke="#e23a2a" strokeWidth="1.6" strokeLinecap="round" /><path d="M45,30 L52,36 L46,38" fill="none" stroke="#e23a2a" strokeWidth="1.6" strokeLinecap="round" /></svg>,
    'down-right': <svg width="60" height="40" viewBox="0 0 60 40"><path d="M55,5 C40,10 30,20 10,35" fill="none" stroke="#e23a2a" strokeWidth="1.6" strokeLinecap="round" /><path d="M15,30 L8,36 L14,38" fill="none" stroke="#e23a2a" strokeWidth="1.6" strokeLinecap="round" /></svg>,
    'up-left': <svg width="60" height="40" viewBox="0 0 60 40"><path d="M5,35 C20,30 30,20 50,5" fill="none" stroke="#e23a2a" strokeWidth="1.6" strokeLinecap="round" /><path d="M45,10 L52,4 L46,2" fill="none" stroke="#e23a2a" strokeWidth="1.6" strokeLinecap="round" /></svg>,
  };
  return (
    <div className="anno" style={style}>
      <div>{children}</div>
      {arrows[arrow]}
    </div>
  );
}

// Tiny icon helpers
const IconSearch = () => <svg width="12" height="12" viewBox="0 0 12 12"><circle cx="5" cy="5" r="3.5" fill="none" stroke="currentColor" strokeWidth="1.4" /><path d="M7.5,7.5 L10,10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>;
const IconX = () => <svg width="10" height="10" viewBox="0 0 10 10"><path d="M1,1 L9,9 M9,1 L1,9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>;

// ═════════════════════════════════════════════════════════
// ARTBOARD 1 — Classic split (map + list + top filters)
// ═════════════════════════════════════════════════════════
function WF1() {
  return (
    <div className="wf" style={{ width: 1000, height: 620 }}>
      {/* top bar */}
      <div style={{ height: 44, borderBottom: '1.5px solid #2a2a2a', display: 'flex', alignItems: 'center', padding: '0 16px', gap: 12 }}>
        <div style={{ fontFamily: 'Caveat, cursive', fontSize: 22, fontWeight: 700 }}>maps of making</div>
        <div className="mono" style={{ color: '#888' }}>/ v0.1 — pilot</div>
        <div style={{ flex: 1 }} />
        <div className="box h-row" style={{ padding: '4px 10px', gap: 6, width: 200 }}>
          <IconSearch /> <span className="mono" style={{ color: '#888' }}>search spaces…</span>
        </div>
        <div className="btn">＋ add URL</div>
      </div>
      {/* filter bar */}
      <div style={{ height: 40, borderBottom: '1.5px solid #2a2a2a', display: 'flex', alignItems: 'center', padding: '0 16px', gap: 8, background: '#fff' }}>
        <span className="wf-label">Filter:</span>
        <span className="chip on">All networks</span>
        <span className="chip">RFF</span>
        <span className="chip">VOW</span>
        <span className="chip">VULCA</span>
        <div style={{ width: 1, height: 20, background: '#2a2a2a', opacity: 0.3, margin: '0 4px' }} />
        <span className="chip">wood</span>
        <span className="chip">metal</span>
        <span className="chip">electronics</span>
        <span className="chip">+ 19 more</span>
        <div style={{ flex: 1 }} />
        <span className="mono" style={{ color: '#888' }}>40 / 40 spaces</span>
      </div>
      {/* body */}
      <div style={{ display: 'flex', height: 'calc(100% - 84px)' }}>
        <div style={{ flex: 1, borderRight: '1.5px solid #2a2a2a', position: 'relative' }}>
          <SketchMap pins={SAMPLE_PINS} caption="OSM + MapLibre (hi-fi)" />
          {/* pin legend */}
          <div className="box" style={{ position: 'absolute', bottom: 12, left: 12, padding: '8px 10px', fontSize: 10 }}>
            <div className="wf-label" style={{ marginBottom: 4 }}>legend</div>
            <div className="h-row" style={{ gap: 6, marginBottom: 3 }}><span className="pin pin-seeded" /><span>seeded</span></div>
            <div className="h-row" style={{ gap: 6, marginBottom: 3 }}><span className="pin pin-confirmed" /><span>confirmed</span></div>
            <div className="h-row" style={{ gap: 6, marginBottom: 3 }}><span className="pin pin-open" /><span>open now</span></div>
            <div className="h-row" style={{ gap: 6, marginBottom: 3 }}><span className="pin pin-stale" /><span>stale</span></div>
            <div className="h-row" style={{ gap: 6 }}><span className="pin pin-broken" /><span>broken</span></div>
          </div>
        </div>
        <div style={{ width: 320, background: '#faf7f0', overflow: 'hidden' }}>
          <div style={{ padding: '10px 14px', borderBottom: '1.5px solid #2a2a2a' }}>
            <div className="wf-label">results · sort: distance ▾</div>
          </div>
          {[
            ['FabLab Ouvert de Paris', 'Paris, FR · RFF', 'confirmed'],
            ['Offene Werkstatt Berlin', 'Berlin, DE · VOW', 'open'],
            ["L'Atelier du Coin — Lyon", 'Lyon, FR · RFF · VULCA', 'seeded'],
            ['Werkhof München', 'München, DE · VOW', 'open'],
            ['La Forge de Nantes', 'Nantes, FR · RFF', 'seeded'],
            ['Hackspace Leipzig', 'Leipzig, DE · VOW', 'stale'],
            ['FabLab Municipal Lille', 'Lille, FR · RFF', 'confirmed'],
          ].map((r, i) => (
            <div key={i} style={{ padding: '10px 14px', borderBottom: '1px dashed #2a2a2a' }}>
              <div className="h-row" style={{ gap: 8 }}>
                <span className={`pin pin-${r[2]}`} />
                <div style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{r[0]}</div>
              </div>
              <div className="mono" style={{ color: '#888', marginTop: 2 }}>{r[1]}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════
// ARTBOARD 2 — Map-first / floating drawer
// ═════════════════════════════════════════════════════════
function WF2() {
  return (
    <div className="wf" style={{ width: 1000, height: 620 }}>
      {/* fullscreen map */}
      <SketchMap pins={SAMPLE_PINS} caption="fullscreen" />
      {/* floating title */}
      <div style={{ position: 'absolute', top: 20, left: 20, fontFamily: 'Caveat, cursive', fontSize: 28, fontWeight: 700, background: '#faf7f0', padding: '4px 12px', border: '1.5px solid #2a2a2a' }}>
        maps of making
      </div>
      {/* floating search bar */}
      <div className="box h-row" style={{ position: 'absolute', top: 24, right: 20, padding: '8px 12px', width: 280, background: '#faf7f0', gap: 8, boxShadow: '3px 3px 0 #2a2a2a' }}>
        <IconSearch /> <span className="mono" style={{ flex: 1, color: '#888' }}>Paris, woodworking…</span>
      </div>
      {/* floating filter chips */}
      <div style={{ position: 'absolute', top: 80, left: 20, display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div className="chip on" style={{ background: '#faf7f0', color: '#1a1a1a', border: '1.5px solid #2a2a2a', boxShadow: '2px 2px 0 #2a2a2a' }}>🗺 All 40</div>
        <div className="chip" style={{ background: '#faf7f0', boxShadow: '2px 2px 0 #2a2a2a' }}>🇫🇷 RFF · 20</div>
        <div className="chip" style={{ background: '#faf7f0', boxShadow: '2px 2px 0 #2a2a2a' }}>🇩🇪 VOW · 20</div>
        <div className="chip" style={{ background: '#faf7f0', boxShadow: '2px 2px 0 #2a2a2a' }}>🔵 Confirmed · 11</div>
        <div className="chip" style={{ background: '#faf7f0', boxShadow: '2px 2px 0 #2a2a2a' }}>🟢 Open now · 4</div>
      </div>
      {/* floating zoom control */}
      <div style={{ position: 'absolute', top: 80, right: 20, background: '#faf7f0', border: '1.5px solid #2a2a2a', boxShadow: '2px 2px 0 #2a2a2a' }}>
        <div style={{ padding: '6px 10px', borderBottom: '1px solid #2a2a2a', fontFamily: 'JetBrains Mono, monospace', fontSize: 14, textAlign: 'center' }}>＋</div>
        <div style={{ padding: '6px 10px', fontFamily: 'JetBrains Mono, monospace', fontSize: 14, textAlign: 'center' }}>−</div>
      </div>
      {/* bottom drawer — space detail */}
      <div className="box" style={{ position: 'absolute', left: 20, right: 20, bottom: 20, background: '#faf7f0', boxShadow: '4px 4px 0 #2a2a2a', padding: '14px 18px', display: 'flex', gap: 20 }}>
        <div style={{ flex: 1 }}>
          <div className="h-row" style={{ gap: 8 }}>
            <span className="pin pin-open" />
            <div style={{ fontFamily: 'Caveat, cursive', fontSize: 22, fontWeight: 700 }}>Offene Werkstatt Berlin</div>
            <span className="chip" style={{ color: '#2aa866', borderColor: '#2aa866' }}>open now</span>
            <span className="chip">VOW</span>
          </div>
          <div className="mono" style={{ color: '#888', marginTop: 4 }}>Werkstraße 47, Berlin · fetched 2h ago</div>
          <div style={{ display: 'flex', gap: 20, marginTop: 10 }}>
            <div>
              <div className="wf-label">specialties</div>
              <div style={{ marginTop: 4 }}>
                <span className="chip">wood</span> <span className="chip">electronics</span> <span className="chip">3d-print</span>
              </div>
            </div>
            <div>
              <div className="wf-label">hours</div>
              <div className="mono" style={{ marginTop: 4, fontSize: 11 }}>Mo–Do 16:00–21:00</div>
            </div>
          </div>
        </div>
        <div style={{ width: 280, background: '#ece4d0', border: '1.5px dashed #2a2a2a', padding: 10 }}>
          <div className="wf-label">raw JSON from endpoint</div>
          <div className="mono" style={{ fontSize: 9, lineHeight: 1.4, marginTop: 4, whiteSpace: 'pre', color: '#555' }}>
{`{
  "name": "Offene Werkstatt…",
  "status": "open",
  "specialties": […],
  "opening_hours": "Mo–Do…"
}`}
          </div>
        </div>
      </div>
      <Annotation style={{ top: 110, right: 170 }} arrow="down-left">filters as floating riso chips</Annotation>
    </div>
  );
}

// ═════════════════════════════════════════════════════════
// ARTBOARD 3 — Zine / atlas (multi-column paper spread)
// ═════════════════════════════════════════════════════════
function WF3() {
  return (
    <div className="wf" style={{ width: 1000, height: 620, padding: 20, boxSizing: 'border-box' }}>
      {/* masthead */}
      <div style={{ display: 'flex', alignItems: 'baseline', borderBottom: '3px double #2a2a2a', paddingBottom: 8, marginBottom: 12 }}>
        <div style={{ fontFamily: 'Caveat, cursive', fontSize: 34, fontWeight: 700, lineHeight: 1 }}>maps of making</div>
        <div style={{ flex: 1 }} />
        <div className="mono" style={{ color: '#888' }}>issue 01 · RFF × VOW pilot · Apr 2026</div>
      </div>
      {/* 3-col grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr 220px', gap: 14, height: 520 }}>
        {/* col 1 — TOC / filters */}
        <div>
          <div className="wf-label" style={{ marginBottom: 6 }}>— contents —</div>
          <div style={{ fontSize: 12, lineHeight: 1.9 }}>
            <div style={{ fontWeight: 600 }}>01 · the map</div>
            <div style={{ color: '#666' }}>02 · by network</div>
            <div style={{ color: '#666' }}>03 · freshly updated</div>
            <div style={{ color: '#666' }}>04 · needing love</div>
            <div style={{ color: '#666' }}>05 · schema</div>
          </div>
          <div className="sep-dashed" />
          <div className="wf-label" style={{ marginBottom: 6 }}>— filters —</div>
          <div className="v-col" style={{ gap: 4 }}>
            <div className="mono" style={{ fontSize: 10 }}>□ RFF (20)</div>
            <div className="mono" style={{ fontSize: 10 }}>□ VOW (20)</div>
            <div className="mono" style={{ fontSize: 10 }}>□ VULCA (11)</div>
            <div className="mono" style={{ fontSize: 10 }}>————</div>
            <div className="mono" style={{ fontSize: 10 }}>☑ seeded (25)</div>
            <div className="mono" style={{ fontSize: 10 }}>☑ confirmed (11)</div>
            <div className="mono" style={{ fontSize: 10 }}>□ stale (3)</div>
          </div>
        </div>
        {/* col 2 — big map */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="box" style={{ flex: 1, padding: 0, overflow: 'hidden' }}>
            <SketchMap pins={SAMPLE_PINS} caption="fig. 1 — the federated map" />
          </div>
          {/* stats strip */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10 }}>
            {[['40','spaces'], ['11','confirmed'], ['2','countries'], ['22','specialties']].map(([n,l]) => (
              <div key={l} className="box" style={{ padding: '8px 10px', textAlign: 'center' }}>
                <div style={{ fontFamily: 'Caveat, cursive', fontSize: 26, fontWeight: 700 }}>{n}</div>
                <div className="wf-label">{l}</div>
              </div>
            ))}
          </div>
        </div>
        {/* col 3 — recently updated */}
        <div>
          <div className="wf-label" style={{ marginBottom: 6 }}>— recently updated —</div>
          {[
            ['FabLab Paris', '2h ago'],
            ['Werkhof München', '5h ago'],
            ['Hackspace Köln', '1d ago'],
            ['FabLab Lille', '2d ago'],
          ].map(([n,t]) => (
            <div key={n} style={{ padding: '6px 0', borderBottom: '1px dashed #2a2a2a' }}>
              <div style={{ fontSize: 11, fontWeight: 500 }}>{n}</div>
              <div className="mono" style={{ color: '#888' }}>· {t}</div>
            </div>
          ))}
          <div className="sep-dashed" />
          <div className="wf-label" style={{ marginBottom: 6 }}>— needs love —</div>
          <div style={{ fontSize: 11, lineHeight: 1.6 }}>
            <div className="h-row" style={{ gap: 6 }}><span className="pin pin-stale" /> Hackspace Leipzig</div>
            <div className="h-row" style={{ gap: 6 }}><span className="pin pin-stale" /> FabLab Toulouse</div>
            <div className="h-row" style={{ gap: 6 }}><span className="pin pin-broken" /> Werkstatt Frankfurt</div>
          </div>
        </div>
      </div>
      <Annotation style={{ top: 30, left: 280 }} arrow="down-left">map is one panel among many</Annotation>
    </div>
  );
}

// ═════════════════════════════════════════════════════════
// ARTBOARD 4 — Pilot dashboard / ingestion HQ
// ═════════════════════════════════════════════════════════
function WF4() {
  return (
    <div className="wf" style={{ width: 1000, height: 620 }}>
      {/* top bar */}
      <div style={{ height: 44, borderBottom: '1.5px solid #2a2a2a', display: 'flex', alignItems: 'center', padding: '0 16px', gap: 12, background: '#1a1a1a', color: '#faf7f0' }}>
        <div style={{ fontFamily: 'Caveat, cursive', fontSize: 22, fontWeight: 700 }}>maps of making · pilot HQ</div>
        <div className="mono" style={{ opacity: 0.7 }}>/ ingestion dashboard</div>
        <div style={{ flex: 1 }} />
        <span className="mono" style={{ opacity: 0.7 }}>oxigraph · 40 endpoints · 3,128 triples</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, padding: 12, height: 'calc(100% - 44px)', boxSizing: 'border-box' }}>
        {/* quadrant A — URL ingestion table */}
        <div className="box" style={{ padding: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div className="h-row" style={{ justifyContent: 'space-between' }}>
            <div style={{ fontFamily: 'Caveat, cursive', fontSize: 20, fontWeight: 700 }}>endpoints</div>
            <div className="btn btn-red">＋ add URL</div>
          </div>
          <div className="sep" />
          <div className="mono" style={{ fontSize: 10, display: 'grid', gridTemplateColumns: '18px 1fr 70px 70px', gap: 4, color: '#888' }}>
            <div>●</div><div>endpoint</div><div>last ok</div><div>status</div>
          </div>
          {[
            ['confirmed','fablab-paris.fr/maker.json', '2h','200'],
            ['open','werkhof-muenchen.de/ok.json', '1h','200'],
            ['seeded','— (not yet claimed)','—','—'],
            ['stale','hackspace-leipzig.de/ok.json','94d','200'],
            ['broken','werkstatt-frankfurt.de/404.json','—','404'],
            ['confirmed','fablab-lille.fr/maker.json','1d','200'],
            ['seeded','— (not yet claimed)','—','—'],
            ['stale','atelier-toulouse.fr/ok.json','62d','200'],
          ].map((r,i) => (
            <div key={i} className="mono" style={{ fontSize: 10, display: 'grid', gridTemplateColumns: '18px 1fr 70px 70px', gap: 4, padding: '4px 0', borderBottom: '1px dashed #ddd', alignItems: 'center' }}>
              <span className={`pin pin-${r[0]}`} style={{ width: 10, height: 10 }} />
              <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r[1]}</div>
              <div>{r[2]}</div>
              <div style={{ color: r[3]==='404' ? '#e23a2a' : '#2aa866' }}>{r[3]}</div>
            </div>
          ))}
        </div>
        {/* quadrant B — mini map */}
        <div className="box" style={{ padding: 0, overflow: 'hidden', position: 'relative' }}>
          <SketchMap pins={SAMPLE_PINS} caption="overview" />
          <div style={{ position: 'absolute', top: 8, left: 8, fontFamily: 'Caveat, cursive', fontSize: 18, fontWeight: 700, background: '#faf7f0', padding: '2px 8px', border: '1.5px solid #2a2a2a' }}>overview</div>
        </div>
        {/* quadrant C — ingestion health */}
        <div className="box" style={{ padding: 10 }}>
          <div style={{ fontFamily: 'Caveat, cursive', fontSize: 20, fontWeight: 700, marginBottom: 6 }}>ingestion health · 24h</div>
          <div style={{ display: 'flex', gap: 2, alignItems: 'flex-end', height: 60, borderBottom: '1.5px solid #2a2a2a' }}>
            {[40,30,28,45,60,55,70,40,38,50,65,80,75,60,55,70,62,58,50,45,48,52,44,38].map((h,i) => (
              <div key={i} style={{ flex: 1, background: i%6===5 ? '#e23a2a' : '#1a1a1a', height: `${h}%` }} />
            ))}
          </div>
          <div className="h-row" style={{ justifyContent: 'space-between', marginTop: 4 }}>
            <span className="mono" style={{ color: '#888' }}>24h ago</span>
            <span className="mono" style={{ color: '#888' }}>now</span>
          </div>
          <div className="sep-dashed" />
          <div className="mono" style={{ fontSize: 10, lineHeight: 1.7 }}>
            <div>✓ 38 successful fetches</div>
            <div style={{ color: '#e23a2a' }}>✗ 2 failed (Frankfurt 404, Leipzig timeout)</div>
            <div>↻ next poll in 14min</div>
          </div>
        </div>
        {/* quadrant D — json→ttl preview */}
        <div className="box" style={{ padding: 10 }}>
          <div style={{ fontFamily: 'Caveat, cursive', fontSize: 20, fontWeight: 700, marginBottom: 6 }}>json → ttl → oxigraph</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <div className="box-dashed" style={{ padding: 6, border: '1.5px dashed #2a2a2a' }}>
              <div className="wf-label">endpoint json</div>
              <div className="mono" style={{ fontSize: 9, whiteSpace: 'pre', marginTop: 4, color: '#555' }}>
{`{
  "name": "FabLab Paris",
  "specialties": [
    "wood","electronics"
  ]
}`}
              </div>
            </div>
            <div className="box-dashed" style={{ padding: 6, border: '1.5px dashed #e23a2a' }}>
              <div className="wf-label" style={{ color: '#e23a2a' }}>turtle</div>
              <div className="mono" style={{ fontSize: 9, whiteSpace: 'pre', marginTop: 4, color: '#555' }}>
{`<#> a mom:Space ;
  mom:name "FabLab…" ;
  mom:spec mom:wood,
           mom:electronics .`}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Annotation style={{ top: 70, right: 450 }} arrow="down-right">monitor json→ttl ingestion</Annotation>
    </div>
  );
}

// ═════════════════════════════════════════════════════════
// ARTBOARD 5 — Query-first / LOD playground
// ═════════════════════════════════════════════════════════
function WF5() {
  return (
    <div className="wf" style={{ width: 1000, height: 620 }}>
      {/* top */}
      <div style={{ padding: '16px 20px', borderBottom: '1.5px solid #2a2a2a' }}>
        <div className="h-row">
          <div style={{ fontFamily: 'Caveat, cursive', fontSize: 22, fontWeight: 700 }}>maps of making</div>
          <div className="mono" style={{ color: '#888', marginLeft: 8 }}>/ ask the map</div>
          <div style={{ flex: 1 }} />
          <div className="mono" style={{ color: '#888' }}>presets · ⚙ admin · 🤖 bot</div>
        </div>
        {/* big query bar */}
        <div className="box" style={{ marginTop: 10, padding: '12px 14px', background: '#fff', boxShadow: '3px 3px 0 #2a2a2a' }}>
          <div className="wf-label" style={{ marginBottom: 4 }}>ask in plain language — we write the SPARQL</div>
          <div style={{ fontFamily: 'Inter Tight, sans-serif', fontSize: 18 }}>
            <span style={{ color: '#1a1a1a' }}>Show me </span>
            <span style={{ background: '#ffef9a', padding: '0 4px' }}>confirmed</span>
            <span> spaces with </span>
            <span style={{ background: '#ffef9a', padding: '0 4px' }}>woodworking</span>
            <span> in </span>
            <span style={{ background: '#ffef9a', padding: '0 4px' }}>Germany</span>
            <span> that are </span>
            <span style={{ background: '#c2e6ff', padding: '0 4px' }}>open for hosting</span>
            <span className="hand" style={{ fontSize: 22, marginLeft: 6 }}>|</span>
          </div>
          <div className="h-row" style={{ marginTop: 10, gap: 8 }}>
            <span className="chip">near me</span>
            <span className="chip">in RFF</span>
            <span className="chip">recently updated</span>
            <span className="chip">with laser</span>
            <div style={{ flex: 1 }} />
            <div className="btn">preview SPARQL</div>
            <div className="btn btn-red">run → map</div>
          </div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', height: 'calc(100% - 168px)' }}>
        {/* sparql preview */}
        <div style={{ borderRight: '1.5px solid #2a2a2a', padding: 12, background: '#faf7f0' }}>
          <div className="wf-label">generated SPARQL</div>
          <div className="mono" style={{ fontSize: 10, whiteSpace: 'pre', marginTop: 6, lineHeight: 1.5, color: '#333' }}>
{`PREFIX mom: <https://mom.org/ns#>
SELECT ?s ?name ?city WHERE {
  ?s a mom:Space ;
     mom:country "DE" ;
     mom:status "confirmed" ;
     mom:specialty mom:wood ;
     mom:hostingOpen true ;
     mom:name ?name ;
     mom:city ?city .
}
LIMIT 50`}
          </div>
          <div className="sep-dashed" />
          <div className="wf-label">saved presets</div>
          <div style={{ fontSize: 11, marginTop: 4, lineHeight: 1.8 }}>
            <div>★ “Erasmus hosts — metal”</div>
            <div>★ “Biolabs w/ PCR”</div>
            <div>★ “Open tonight, 50km”</div>
            <div style={{ color: '#e23a2a', marginTop: 6 }}>＋ new preset →</div>
            <div className="mono" style={{ fontSize: 9, color: '#888' }}>  &lt;iframe src=…/embed?q=☆&gt;</div>
          </div>
        </div>
        {/* results */}
        <div style={{ display: 'grid', gridTemplateRows: '1fr 130px' }}>
          <div style={{ position: 'relative', borderBottom: '1.5px solid #2a2a2a' }}>
            <SketchMap pins={[
              { x: 52, y: 44, kind: 'confirmed', label: 'Berlin' },
              { x: 46, y: 52, kind: 'confirmed', label: 'Köln' },
              { x: 50, y: 62, kind: 'confirmed', label: 'München' },
              { x: 56, y: 60, kind: 'confirmed', label: 'Nürnberg' },
            ]} caption="4 results" />
            <div style={{ position: 'absolute', top: 10, left: 10, background: '#faf7f0', border: '1.5px solid #2a2a2a', padding: '4px 10px', fontFamily: 'Caveat, cursive', fontSize: 18, fontWeight: 700 }}>4 matches</div>
          </div>
          <div style={{ padding: '8px 12px', display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8, background: '#fff' }}>
            {['Offene Werkstatt Berlin','Werkhof München','Hackspace Köln','Makerhub Nürnberg'].map((n) => (
              <div key={n} className="box" style={{ padding: '8px 10px' }}>
                <div style={{ fontSize: 11, fontWeight: 500 }}>{n}</div>
                <div className="mono" style={{ color: '#888', fontSize: 9, marginTop: 2 }}>wood · confirmed</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────
// Root — DesignCanvas with all 5 boards
// ─────────────────────────────────────────────────────────
function App() {
  return (
    <DesignCanvas>
      <div style={{ padding: '20px 60px 40px' }}>
        <div style={{ fontFamily: 'Caveat, cursive', fontSize: 44, fontWeight: 700, color: '#1a1a1a', lineHeight: 1 }}>
          Maps of Making — wireframes
        </div>
        <div style={{ fontFamily: 'Inter Tight, sans-serif', fontSize: 14, color: '#666', marginTop: 6, maxWidth: 720 }}>
          Five lo-fi directions to explore the design space. Each artboard explores a different emphasis — from classic map+list through query-first LOD playground. Pick one (or mix) and I'll build the hi-fi interactive prototype next. Scroll / pinch to navigate.
        </div>
        <div className="mono" style={{ color: '#888', marginTop: 6 }}>v0 · synthetic data · 40 seed spaces (FR+DE) · zine / riso aesthetic</div>
      </div>

      <DCSection title="Direction 1 — Classic split" subtitle="Map + list + top filter bar. Baseline. Familiar. Works on laptops; cramped on mobile.">
        <DCArtboard label="01 · desktop 1000×620"><WF1 /></DCArtboard>
      </DCSection>

      <DCSection title="Direction 2 — Map-first / floating drawer" subtitle="Fullscreen map. Filters as floating riso chips. Detail slides up from bottom. Most visceral; least info-dense.">
        <DCArtboard label="02 · desktop 1000×620"><WF2 /></DCArtboard>
      </DCSection>

      <DCSection title="Direction 3 — Zine / atlas" subtitle="Paper-spread layout. Map is one panel. Stats, recently-updated, needs-love, schema all co-exist. Editorial tone. Matches article voice.">
        <DCArtboard label="03 · desktop 1000×620"><WF3 /></DCArtboard>
      </DCSection>

      <DCSection title="Direction 4 — Pilot HQ / ingestion dashboard" subtitle="For the coordinator — endpoint health, json→ttl preview, failure queue. Useful eventually (monitoring deploy), probably not for v1 public-facing.">
        <DCArtboard label="04 · desktop 1000×620"><WF4 /></DCArtboard>
      </DCSection>

      <DCSection title="Direction 5 — Query-first / LOD playground" subtitle="Natural-language bar → SPARQL preview → map/list results. Presets are saved queries; embed = preset URL. Closest to the 'bot' vision.">
        <DCArtboard label="05 · desktop 1000×620"><WF5 /></DCArtboard>
      </DCSection>

      <div style={{ padding: '20px 60px 80px', maxWidth: 820 }}>
        <div style={{ fontFamily: 'Caveat, cursive', fontSize: 28, fontWeight: 700, color: '#e23a2a' }}>my recommendation →</div>
        <div style={{ fontFamily: 'Inter Tight, sans-serif', fontSize: 14, color: '#333', lineHeight: 1.6, marginTop: 4 }}>
          For the <b>MVP walking skeleton</b>, I'd combine <b>Direction 2</b> (map-first, floating drawer — best first impression for outreach to spaces) as the main surface, with the <b>admin / add-URL / preset-export</b> flows from Direction 4 tucked behind a modal, and a <b>small bot teaser</b> from Direction 5 docked on the side as a coming-soon. Keeps the v1 focused on "see the map, see yourself on it", while telegraphing where this is going.
        </div>
        <div className="mono" style={{ color: '#888', marginTop: 10 }}>pick one, or reply with your mix (e.g. "2 + admin from 4 + query teaser from 5") and I'll build hi-fi.</div>
      </div>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
